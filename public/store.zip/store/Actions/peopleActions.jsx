import React from 'react'

const peopleActions = () => {
  return (
    <div>
      
    </div>
  )
}

export default peopleActions
